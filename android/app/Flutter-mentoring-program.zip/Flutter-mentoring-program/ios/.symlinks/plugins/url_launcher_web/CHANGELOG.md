# 0.1.0+2

- Remove androidx references from the no-op android implemenation.

# 0.1.0+1

- Add an android/ folder with no-op implementation to workaround https://github.com/flutter/flutter/issues/46304.
- Bump the minimal required Flutter version to 1.10.0.

# 0.1.0

- Update docs and pubspec.

# 0.0.2

- Switch to using `url_launcher_platform_interface`.

# 0.0.1

- Initial open-source release.
