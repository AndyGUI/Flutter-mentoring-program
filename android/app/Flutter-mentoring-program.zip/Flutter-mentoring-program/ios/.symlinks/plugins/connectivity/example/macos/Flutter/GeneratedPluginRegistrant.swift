//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import connectivity_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  ConnectivityPlugin.register(with: registry.registrar(forPlugin: "ConnectivityPlugin"))
}
