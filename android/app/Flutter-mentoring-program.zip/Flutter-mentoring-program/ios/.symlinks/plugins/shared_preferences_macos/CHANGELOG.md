## 0.0.1+3

* Update README.

## 0.0.1+2

* Remove unused onMethodCall method.

## 0.0.1+1

* Add an android/ folder with no-op implementation to workaround https://github.com/flutter/flutter/issues/46898.

## 0.0.1

* Initial open source release.
