# 0.0.1+2

* Update README.

# 0.0.1+1

* Add an android/ folder with no-op implementation to workaround https://

# 0.0.1

* Initial open source release.

